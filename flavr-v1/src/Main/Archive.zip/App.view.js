/* eslint-disable jsx-a11y/accessible-emoji, no-unused-vars, no-dupe-keys */
import '../Fonts/Montserrat-400.js';
import React from 'react';
import { css } from 'emotion';
import FlavList from './components/FlavList'

const App1 = css({
  label: 'App1',
  alignItems: 'center',
  flexGrow: 1,
  flexShrink: 1,
  flexBasis: 'auto',
  justifyContent: 'center',
});
const Text = css({
  label: 'Text',
  fontFamily: 'Montserrat, sans-serif',
  fontWeight: 400,
  fontSize: 18,
});



// FlavorsList()


const App = props => {
  return (
    <div
      data-test-id={`${props['data-test-id'] || 'App'}|`}
      className={`views-block ${App1}`}
    >
      <span data-test-id={`App.Text|`} className={`views-text ${Text}`}>
        {props.text}
      </span>
      {props.children}
      {/*<FlavList flavs={props.flavors} />*/}

    </div>
  );
};
App.defaultProps = { text: 'Hello Views Tools!' };
export default App;
